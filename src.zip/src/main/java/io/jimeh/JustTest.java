package io.jimeh;

import avro.shaded.com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.Immutable;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import org.apache.beam.runners.core.construction.renderer.PipelineDotRenderer;
import org.apache.beam.vendor.grpc.v1p43p2.com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class JustTest {

    // ".apply(Flatten.iterables())" it will convert "PCollection<List>" to "PCollection"

    /*
    public static class Dummy2
            extends PTransform<PCollection<Integer>, PCollection<String>> {
        @Override
        public PCollection<String> expand(PCollection<Integer> ints) {

            // Convert lines of text into individual words.
            PCollection<String> words = ints.apply(ParDo.of(new ExtractWordsFn()));

            // Count the number of times each word occurs.
            PCollection<KV<String, Long>> wordCounts = words.apply(Count.perElement());

            return wordCounts;
        }
    }*/


    static class Dummy2 extends DoFn<Integer, List<String>> {
        @DoFn.ProcessElement
        public void processElement(@Element Integer i, OutputReceiver<List<String>> out) {
            System.out.println("executing: " + i);
            out.output(Lists.newArrayList("dim_table1", "dim_table2"));
        }
    }

    static class Dummy1 extends DoFn<Integer, String> {
        @DoFn.ProcessElement
        public void processElement(@Element Integer i, OutputReceiver<String> out) {
            // Use OutputReceiver.output to emit the output element.
            System.out.println("executing: " + i);
            // sleep();
            out.output("dummy1");
        }
    }


    public static class SumInts implements SerializableFunction<Iterable<Integer>, Integer> {
        @Override
        public Integer apply(Iterable<Integer> input) {
            int sum = 0;
            for (int item : input) {
                sum += item;
            }
            return sum;
        }
    }

    static class SqlExecution extends DoFn<String, Integer> {
        @DoFn.ProcessElement
        public void processElement(@Element String word, OutputReceiver<Integer> out) {
            // Use OutputReceiver.output to emit the output element.
            System.out.println("executing: " + word);
            // sleep();
            out.output(1);
        }
    }

    public static class SqlExecution2 extends PTransform<PCollection<String>, PCollection<Integer>> {
        @Override
        public PCollection<Integer> expand(PCollection<String> words) {

            return null;

            // Convert lines of text into individual words.
            // PCollection<String> words = ints.apply(ParDo.of(new ExtractWordsFn()));

            // Count the number of times each word occurs.
            // PCollection<KV<String, Long>> wordCounts = words.apply(Count.perElement());

            // return wordCounts;
        }
    }

    private static void sleep() {
        try {
            Thread.sleep(10000L);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String args[]) {

        Pipeline p = Pipeline.create();

        var extTables = p
                .apply(Create.of("ext_table1", "ext_table2")).setCoder(StringUtf8Coder.of());


        PCollection<Integer> extTablesResult = extTables.apply(ParDo.of(new SqlExecution()));

        PCollection<Integer> extTablesResult2 = extTablesResult.apply(Combine.globally(new SumInts()));

        PCollection<List<String>> extTablesResult3 = extTablesResult2.apply(ParDo.of(new Dummy2()));

        PCollection<String> extTablesResult4 = extTablesResult3.apply(Flatten.iterables());

        PCollection<Integer> extTablesResul5 = extTablesResult4.apply(ParDo.of(new SqlExecution()));


        //  PCollection<List<String>> extTablesResult4 = extTablesResult3.apply(ParDo.of(new Dummy2()));



        // var dimTables = p.apply(Create.of("dim_table1", "dim_table2")).setCoder(StringUtf8Coder.of());


       // PCollection<Boolean> extTablesResult = dimTables.apply(ParDo.of(new SqlExecution()));
       // PCollection<Boolean>  b = extTablesResult.apply(new SqlExecution2());


        p.run().waitUntilFinish();
    }

}
