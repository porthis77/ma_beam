package io.jimeh;

import org.apache.beam.runners.core.construction.renderer.PipelineDotRenderer;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class AnotherTest {

    static class Dummy1 extends DoFn<String, Integer> {
        @DoFn.ProcessElement
        public void processElement(@Element String str, OutputReceiver<Integer> out) {
            // sleep();
            System.out.println("executing: " + str + " at " + new Date());
            out.output(1);
        }
    }

    static class Dummy2 extends DoFn<Integer, Integer> {

        private final String query;

        Dummy2(String query) {
            this.query = query;
        }

        @DoFn.ProcessElement
        public void processElement(@Element Integer i, OutputReceiver<Integer> out) {
            // sleep();
            System.out.println("executing: " + i + " at " + new Date());
            out.output(1);
        }
    }

    public static class SumInts implements SerializableFunction<Iterable<Integer>, Integer> {
        @Override
        public Integer apply(Iterable<Integer> input) {
            int sum = 0;
            for (int item : input) {
                sum += item;
            }
            return sum;
        }
    }

    private static void sleep() {
        try {
            Thread.sleep(10000L);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static class SqlExecution2 extends PTransform<PCollection<String>, PCollection<String>> {

        private final String query;

        SqlExecution2(String query) {
            this.query = query;
        }

        @Override
        public PCollection<String> expand(PCollection<String> queries) {
            /*
            return queries
                    .apply(ParDo.of(new JustTest3.BigQueryExecution()))
                    .apply(Combine.globally(new JustTest3.SumInts()))
                    .apply(ParDo.of(new JustTest3.NewQueries(queryGroup.getQueries())))
                    .apply(Flatten.iterables());
                    */

            return null;

        }
    }

    public static void main(String args[]) {

        Pipeline p = Pipeline.create();

        var extTables1 = p
                .apply("ext_table1", Create.of("ext_table1"))
                .setCoder(StringUtf8Coder.of())
                .apply("exec ext_table1", ParDo.of(new Dummy1()));

        var extTables2 = p.apply("ext_table2", Create.of("ext_table2"))
                .setCoder(StringUtf8Coder.of())
                .apply("exec ext_table2", ParDo.of(new Dummy1()));


        PCollectionList<Integer> collections = PCollectionList.of(extTables1).and(extTables2);
        PCollection<Integer> merged = collections.apply("all external tables", Flatten.pCollections());
        PCollection<Integer> extTablesResult = merged.apply("all external tables2", Combine.globally(new JustTest.SumInts()));

        var d1 = extTablesResult.apply("exec dim_table1", ParDo.of(new Dummy2("dim_table1")));
        var d2 = extTablesResult.apply("exec dim_table1", ParDo.of(new Dummy2("dim_table1")));

        PCollectionList<Integer> collections2 = PCollectionList.of(d1).and(d2);
        PCollection<Integer> merged2 = collections.apply("all dim tables", Flatten.pCollections());
        PCollection<Integer> dimTablesResult = merged.apply("all dim tables2", Combine.globally(new JustTest.SumInts()));


        saveGraph(p);

        p.run().waitUntilFinish();
    }

    private static void saveGraph(Pipeline p) {
        final Logger log = LoggerFactory.getLogger(AnotherTest.class);
        String dotString = PipelineDotRenderer.toDotString(p);
        log.info("GRAPH: " + dotString);

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("pipeline_graph.dot"));
            writer.write(dotString);
            writer.close();
        } catch (IOException e) {
            log.error("Error writing pipeline graph to file.");
        }
    }

}
