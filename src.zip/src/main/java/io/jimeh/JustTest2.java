package io.jimeh;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.PBegin;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.vendor.grpc.v1p43p2.com.google.common.collect.ImmutableList;

import java.util.ArrayList;
import java.util.List;

public class JustTest2 {

    // ".apply(Flatten.iterables())" it will convert "PCollection<List>" to "PCollection"

    /*
    public static class Dummy2
            extends PTransform<PCollection<Integer>, PCollection<String>> {
        @Override
        public PCollection<String> expand(PCollection<Integer> ints) {

            // Convert lines of text into individual words.
            PCollection<String> words = ints.apply(ParDo.of(new ExtractWordsFn()));

            // Count the number of times each word occurs.
            PCollection<KV<String, Long>> wordCounts = words.apply(Count.perElement());

            return wordCounts;
        }
    }*/

    public static class Dummy3 extends PTransform<PCollection<Integer>, PCollection<String>> {

        private final List<String> list;

        Dummy3(List<String> list) {
            this.list = list;
        }

        @Override
        public PCollection<String> expand(PCollection<Integer> results) {

            PCollection<List<String>> results2 = results.apply(ParDo.of(new DoFn<Integer, List<String>>() {
                @ProcessElement
                public void processElement(@Element Integer i, OutputReceiver<List<String>> out, ProcessContext c) {
                    System.out.println("executing: " + i);
                    out.output(list);
                }
            }));

            return results2.apply(Flatten.iterables());
        }
    }


    static class Dummy2 extends DoFn<Integer, List<String>> {

        private final List<String> list;

        Dummy2(List<String> list) {
            this.list = list;
        }

        @ProcessElement
        public void processElement(@Element Integer i, OutputReceiver<List<String>> out) {
            System.out.println("executing: " + i);
            out.output(list);
        }
    }

    static class Dummy1 extends DoFn<Integer, String> {
        @ProcessElement
        public void processElement(@Element Integer i, OutputReceiver<String> out) {
            // Use OutputReceiver.output to emit the output element.
            System.out.println("executing: " + i);
            // sleep();
            out.output("dummy1");
        }
    }


    public static class SumInts implements SerializableFunction<Iterable<Integer>, Integer> {
        @Override
        public Integer apply(Iterable<Integer> input) {
            int sum = 0;
            for (int item : input) {
                sum += item;
            }
            return sum;
        }
    }



    private static void sleep() {
        try {
            Thread.sleep(10000L);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static class SqlExecution2 extends PTransform<PCollection<String>, PCollection<String>> {

        private final List<String> list;

        SqlExecution2(List<String> list) {
            this.list = list;
        }

        @Override
        public PCollection<String> expand(PCollection<String> words) {

            PCollection<Integer> results = words.apply(ParDo.of(new DoFn<String, Integer>() {
                @ProcessElement
                public void processElement(@Element String word, OutputReceiver<Integer> out, ProcessContext c) {
                    System.out.println("executing: " + word);
                    out.output(1);
                }
            }));

            var results2 = results.apply(Combine.globally(new SumInts()));

            PCollection<List<String>> results3 = results2.apply(ParDo.of(new DoFn<Integer, List<String>>() {
                @ProcessElement
                public void processElement(@Element Integer i, OutputReceiver<List<String>> out, ProcessContext c) {
                    System.out.println("executing: " + i);
                    out.output(list);
                }
            }));

            return results3.apply(Flatten.iterables());
        }
    }

    static class BigQueryExecution extends DoFn<String, Integer> {
        @ProcessElement
        public void processElement(@Element String query, OutputReceiver<Integer> out) {
            System.out.println("executing: " + query);
            out.output(1);
        }
    }

    static class NewQueries extends DoFn<Integer, List<String>> {

        private final List<String> queries;

        NewQueries(List<String> queries) {
            this.queries = queries;
        }

        @ProcessElement
        public void processElement(@Element Integer result, OutputReceiver<List<String>> out) {
            out.output(queries);
        }
    }


    static class SqlExecution3 extends PTransform<PBegin, PCollection<String>> {

        private final List<List<String>> allQueries;

        public SqlExecution3(List<List<String>> allQueries) {
            this.allQueries = allQueries;
        }

        @Override
        public PCollection<String> expand(PBegin begin) {

            PCollection<String> currentQueries = null;
            for (var queries : allQueries) {
                if(currentQueries == null) {
                    currentQueries = begin.apply(Create.of(queries));
                } else {
                    PCollection<Integer> result = currentQueries
                            .apply(ParDo.of(new BigQueryExecution()))
                            .apply(Combine.globally(new SumInts()));

                   result.apply(ParDo.of(new NewQueries(queries))).apply(Flatten.iterables());

                    /*
                    PCollection<List<String>> results3 = result.apply(ParDo.of(new DoFn<Integer, List<String>>() {
                        @ProcessElement
                        public void processElement(@Element Integer i, OutputReceiver<List<String>> out, ProcessContext c) {
                            // System.out.println("executing: " + i);
                            out.output(queries);
                        }
                    }));

                    results3.apply(Flatten.iterables());
                    */

                }
            }

            return currentQueries;
        }
    }

    public static void main(String args[]) {

        Pipeline p = Pipeline.create();

        List<List<String>> list = new ArrayList<>();
        list.add(ImmutableList.of("ext_table1", "ext_table2"));
        list.add(ImmutableList.of("dim_table1", "dim_table2"));
        list.add(ImmutableList.of("end"));

        /*
        PCollection<String> queryPCollection = null;
        PCollection<Integer> queryResult = null;
        for (var queries : list) {
            if(queryPCollection == null) {
                queryPCollection = p.apply(Create.of(queries));
            } else {
                queryPCollection = queryPCollection
            }

            queryResult = queryPCollection.apply(new SqlExecution2());
        }*/

        p.apply(new SqlExecution3(list));

        //var extTables = p
         //       .apply(Create.of("ext_table1", "ext_table2")).setCoder(StringUtf8Coder.of());


       // PCollection<Integer> extTablesResult = extTables.apply(new SqlExecution2(ImmutableList.of("dim_table", "dim_table2"));
       // PCollection<String> extTablesResul2 = extTablesResult.apply(new Dummy3(ImmutableList.of("dim_table", "dim_table2")));
        //PCollection<Integer> extTablesResul4 = extTablesResul2.apply(new SqlExecution2());




        p.run().waitUntilFinish();
    }

}
