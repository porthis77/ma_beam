package io.jimeh;

import io.jimeh.model.QueryGroup;
import org.apache.beam.runners.core.construction.renderer.PipelineDotRenderer;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.PBegin;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.vendor.grpc.v1p43p2.com.google.common.collect.ImmutableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JustTest3 {

    public static class SumInts implements SerializableFunction<Iterable<Integer>, Integer> {
        @Override
        public Integer apply(Iterable<Integer> input) {
            int sum = 0;
            for (int item : input) {
                sum += item;
            }
            return sum;
        }
    }

    public static class SqlExecution2 extends PTransform<PCollection<String>, PCollection<String>> {

        private final QueryGroup queryGroup;

        SqlExecution2(QueryGroup queryGroup) {
            this.queryGroup = queryGroup;
        }

        @Override
        public PCollection<String> expand(PCollection<String> queries) {
            return queries
                    .apply(ParDo.of(new BigQueryExecution()))
                    .apply(Combine.globally(new SumInts()))
                    .apply(ParDo.of(new NewQueries(queryGroup.getQueries())))
                    .apply(Flatten.iterables());
        }
    }

    static class BigQueryExecution extends DoFn<String, Integer> {
        @ProcessElement
        public void processElement(@Element String query, OutputReceiver<Integer> out) {
            System.out.println("executing: " + query);
            out.output(1);
        }
    }

    static class NewQueries extends DoFn<Integer, List<String>> {

        private final List<String> queries;

        NewQueries(List<String> queries) {
            this.queries = queries;
        }

        @ProcessElement
        public void processElement(@Element Integer result, OutputReceiver<List<String>> out) {
            out.output(queries);
        }
    }


    public static void main(String args[]) {

        Pipeline p = Pipeline.create();

        List<QueryGroup> groups = new ArrayList<>();
        groups.add(new QueryGroup("external_tables", ImmutableList.of("ext_table1", "ext_table2")));
        groups.add(new QueryGroup("dim_tables", ImmutableList.of("dim_table1", "dim_table2")));
        groups.add(new QueryGroup("end", ImmutableList.of("end")));


        PCollection<String> currentQueries = null;
        for (var queryGroup : groups) {
            if(currentQueries == null) {
                currentQueries =  p.apply(queryGroup.getGroupName(), Create.of(queryGroup.getQueries()));
            } else {
                currentQueries = currentQueries.apply(queryGroup.getGroupName(), new SqlExecution2(queryGroup));
            }
        }


        p.run().waitUntilFinish();
    }

    private static void saveGraph(Pipeline p) {
        final Logger log = LoggerFactory.getLogger(JustTest3.class);
        String dotString = PipelineDotRenderer.toDotString(p);
        log.info("GRAPH: " + dotString);

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("pipeline_graph.dot"));
            writer.write(dotString);
            writer.close();
        } catch (IOException e) {
            log.error("Error writing pipeline graph to file.");
        }
    }

}
