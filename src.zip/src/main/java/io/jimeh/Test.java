/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.jimeh;

import org.apache.beam.runners.core.construction.renderer.PipelineDotRenderer;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Test {

    static class ComputeWordLengthFn extends DoFn<String, Integer> {
        @DoFn.ProcessElement
        public void processElement(@Element String word, OutputReceiver<Integer> out) {
            if(word.equals("a")) {
                try {
                    //Thread.sleep(10000);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            out.output(word.length());
        }
    }

    public static void main(String[] args) {
        /*
        E1 -> T1
        E2 -> T2

        (T1 + T2) -> T3
         */

        // KeyedPCollectionTuple.of()

        PipelineOptions options = PipelineOptionsFactory.create();

        Pipeline p = Pipeline.create(options);

        var words = p.apply("CreateWords", Create.of("a", "b")).setCoder(StringUtf8Coder.of());
        PCollection<Integer> wordLengths = words.apply("ComputeLength", ParDo.of(new ComputeWordLengthFn()));

        var words2 = p.apply("CreateWords2", Create.of("c", "d")).setCoder(StringUtf8Coder.of());
        PCollection<Integer> wordLengths2 = words2.apply("ComputeLength2", ParDo.of(new ComputeWordLengthFn()));

        // Code to show how to dump pipeline representation ::START::
        final Logger log = LoggerFactory.getLogger(Test.class);
        String dotString = PipelineDotRenderer.toDotString(p);
        log.info("GRAPH: " + dotString);

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("pipeline_graph.dot"));
            writer.write(dotString);
            writer.close();
        } catch (IOException e) {
            log.error("Error writing pipeline graph to file.");
        }
        // Code to show how to dump pipeline representation ::END::

        p.run().waitUntilFinish();
    }
}
