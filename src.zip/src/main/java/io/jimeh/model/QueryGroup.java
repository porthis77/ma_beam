package io.jimeh.model;

import java.util.List;

public class QueryGroup {

    private final String groupName;

    private final List<String> queries;

    public QueryGroup(String groupName, List<String> queries) {
        this.groupName = groupName;
        this.queries = queries;
    }

    public String getGroupName() {
        return groupName;
    }

    public List<String> getQueries() {
        return queries;
    }
}
